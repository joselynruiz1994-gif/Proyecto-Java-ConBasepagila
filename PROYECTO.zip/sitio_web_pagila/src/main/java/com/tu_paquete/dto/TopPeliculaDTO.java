package com.tu_paquete.dto;

public class TopPeliculaDTO {
	
	private String titulo;
    private Long totalAlquileres;

    public TopPeliculaDTO(String titulo, Long totalAlquileres) {
        this.titulo = titulo;
        this.totalAlquileres = totalAlquileres;
    }

    public String getTitulo() {
        return titulo;
    }

    public Long getTotalAlquileres() {
        return totalAlquileres;
    }


}
