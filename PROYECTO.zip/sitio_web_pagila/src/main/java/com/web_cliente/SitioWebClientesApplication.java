package com.web_cliente;
import org.springframework.boot.CommandLineRunner;

import org.springframework.context.annotation.Bean;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SitioWebClientesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SitioWebClientesApplication.class, args);
	}
	
//	@Bean
//  CommandLineRunner test(ClienteRepositoryBd repo) {
//    return args -> {
//      repo.save(new Cliente("1", "César", "Alcívar", 41));
//      repo.save(new Cliente("2", "Galo", "Vera", 10));
//      System.out.println("Total clientes: " + repo.count());
//    };
//  }

}

