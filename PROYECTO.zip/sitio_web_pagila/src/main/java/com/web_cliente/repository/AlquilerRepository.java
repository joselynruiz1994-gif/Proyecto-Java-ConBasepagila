package com.web_cliente.repository;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
@Repository
public class AlquilerRepository {
	@PersistenceContext
    private EntityManager em;

    // ✅ LISTADO GENERAL
    public List<Object[]> listarAlquileres() {
        return em.createNativeQuery("""
            SELECT 
                r.rental_id,
                c.first_name,
                c.last_name,
                f.title,
                r.rental_date,
                r.return_date,
                s.store_id
            FROM rental r
            JOIN customer c ON r.customer_id = c.customer_id
            JOIN inventory i ON r.inventory_id = i.inventory_id
            JOIN film f ON i.film_id = f.film_id
            JOIN store s ON i.store_id = s.store_id
            ORDER BY r.rental_date DESC
            LIMIT 50
        """).getResultList();
    }

    // ✅ FILTRO POR FECHAS Y TIENDA (REQUERIMIENTO DEL PROYECTO)
    public List<Object[]> listarAlquileresPorFechaYTienda(
    		LocalDateTime inicio,
            LocalDateTime fin,
            Integer tienda) {

    	 StringBuilder sql = new StringBuilder("""
    	            SELECT 
    	                r.rental_id,
    	                c.first_name,
    	                c.last_name,
    	                f.title,
    	                r.rental_date,
    	                r.return_date,
    	                s.store_id
    	            FROM rental r
    	            JOIN customer c ON r.customer_id = c.customer_id
    	            JOIN inventory i ON r.inventory_id = i.inventory_id
    	            JOIN film f ON i.film_id = f.film_id
    	            JOIN store s ON i.store_id = s.store_id
    	            WHERE 1=1
    	        """);

    	        if (inicio != null) {
    	            sql.append(" AND r.rental_date >= :inicio");
    	        }
    	        if (fin != null) {
    	            sql.append(" AND r.rental_date <= :fin");
    	        }
    	        if (tienda != null) {
    	            sql.append(" AND s.store_id = :tienda");
    	        }

    	        sql.append(" ORDER BY r.rental_date");

    	        Query query = em.createNativeQuery(sql.toString());

    	        if (inicio != null) {
    	            query.setParameter("inicio", inicio);
    	        }
    	        if (fin != null) {
    	            query.setParameter("fin", fin);
    	        }
    	        if (tienda != null) {
    	            query.setParameter("tienda", tienda);
    	        }

    	        return query.getResultList();
    	    }
    	}