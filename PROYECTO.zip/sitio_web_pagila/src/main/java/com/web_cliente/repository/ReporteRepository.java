package com.web_cliente.repository;



import java.util.List;

import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository   // 👈 ESTA LÍNEA ES LA CLAVE
public class ReporteRepository {

    @PersistenceContext
    private EntityManager em;

    public List<Object[]> ingresosMensuales() {
        return em.createNativeQuery("""
            SELECT DATE_TRUNC('month', payment_date), SUM(amount)
            FROM payment
            GROUP BY 1
            ORDER BY 1
        """).getResultList();
    }

    public List<Object[]> topPeliculas() {
        return em.createNativeQuery("""
            SELECT f.title, COUNT(r.rental_id)
            FROM rental r
            JOIN inventory i ON r.inventory_id = i.inventory_id
            JOIN film f ON i.film_id = f.film_id
            GROUP BY f.title
            ORDER BY 2 DESC
            LIMIT 10
        """).getResultList();
    }

    public List<Object[]> topClientes() {
        return em.createNativeQuery("""
            SELECT c.first_name, c.last_name, COUNT(r.rental_id)
            FROM rental r
            JOIN customer c ON r.customer_id = c.customer_id
            GROUP BY c.first_name, c.last_name
            ORDER BY 3 DESC
            LIMIT 10
        """).getResultList();
    }
}



