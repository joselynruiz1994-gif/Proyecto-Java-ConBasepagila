package com.web_cliente.repository;

import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
public class DashboardRepository {
	
	@PersistenceContext
    private EntityManager em;

    public Long totalAlquileres() {
        return ((Number) em
            .createNativeQuery("SELECT COUNT(*) FROM rental")
            .getSingleResult()).longValue();
    }

    public Double totalIngresos() {
        return ((Number) em
            .createNativeQuery("SELECT SUM(amount) FROM payment")
            .getSingleResult()).doubleValue();
    }

    public Long clientesActivos() {
        return ((Number) em.createNativeQuery("""
            SELECT COUNT(DISTINCT customer_id)
            FROM rental
            WHERE return_date IS NULL
        """).getSingleResult()).longValue();
    }


}
