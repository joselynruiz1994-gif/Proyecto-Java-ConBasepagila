package com.web_cliente.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.web_cliente.modelo.Rental;




public interface RentalRepository extends CrudRepository<Rental, Long>{
	
	@Query("""
		    SELECT r FROM Rental r
		    WHERE r.customer.customerId = :id
		    """)
		    List<Rental> historial(Long id);
		}


