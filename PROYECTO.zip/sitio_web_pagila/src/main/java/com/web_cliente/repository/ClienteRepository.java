package com.web_cliente.repository;
import java.util.List;

import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
public class ClienteRepository {
	@PersistenceContext
    private EntityManager em;

    public List<Object[]> listarClientes() {
        return em.createNativeQuery("""
            SELECT customer_id, first_name, last_name, email
            FROM customer
            ORDER BY last_name
        """).getResultList();
    }

    public Object buscarCliente(Integer id) {
        return em.createNativeQuery("""
            SELECT customer_id, first_name, last_name, email
            FROM customer
            WHERE customer_id = :id
        """).setParameter("id", id).getSingleResult();
    }

    public List<Object[]> historialAlquileres(Integer id) {
        return em.createNativeQuery("""
            SELECT r.rental_date, f.title
            FROM rental r
            JOIN inventory i ON r.inventory_id = i.inventory_id
            JOIN film f ON i.film_id = f.film_id
            WHERE r.customer_id = :id
            ORDER BY r.rental_date DESC
        """).setParameter("id", id).getResultList();
    }

    public List<Object[]> historialPagos(Integer id) {
        return em.createNativeQuery("""
            SELECT payment_date, amount
            FROM payment
            WHERE customer_id = :id
            ORDER BY payment_date DESC
        """).setParameter("id", id).getResultList();
    }
}
