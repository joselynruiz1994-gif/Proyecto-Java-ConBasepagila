package com.web_cliente.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.web_cliente.modelo.Payment;

public interface PaymentRepository extends CrudRepository<Payment, Long>{
	
	@Query("""
		    SELECT p FROM Payment p
		    WHERE p.customer.customerId = :id
		    """)
		    List<Payment> pagos(Long id);
		
	
	

}
