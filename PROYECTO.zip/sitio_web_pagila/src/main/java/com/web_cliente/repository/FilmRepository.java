package com.web_cliente.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.web_cliente.modelo.Film;

public interface FilmRepository extends JpaRepository<Film,Integer> {

    // 🔹 Listar todas las películas CON actores
    @Query("""
        SELECT DISTINCT f
        FROM Film f
        LEFT JOIN FETCH f.filmActors fa
        LEFT JOIN FETCH fa.actor
    """)
    List<Film> findAllWithActors();

    // 🔹 Buscar por título
    List<Film> findByTitleContainingIgnoreCase(String title);

    // 🔥 FILTRO POR ACTOR (CORRECTO)
    @Query("""
        SELECT DISTINCT f
        FROM Film f
        JOIN f.filmActors fa
        JOIN fa.actor a
        WHERE LOWER(a.firstName) LIKE LOWER(CONCAT('%', :actor, '%'))
           OR LOWER(a.lastName) LIKE LOWER(CONCAT('%', :actor, '%'))
    """)
    List<Film> findByActor(@Param("actor") String actor);
}
	