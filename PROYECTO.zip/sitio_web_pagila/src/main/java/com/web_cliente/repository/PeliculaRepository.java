package com.web_cliente.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
public class PeliculaRepository {

    @PersistenceContext
    private EntityManager em;

    public List<Object[]> buscarPeliculas(
            String titulo,
            String categoria,
            String actor,
            String rating
    ) {

        String sql = """
            SELECT 
                f.title,
                f.release_year,
                f.rating,
                c.name,
                STRING_AGG(
                    DISTINCT a.first_name || ' ' || a.last_name,
                    ', '
                ) AS actores
            FROM film f
            LEFT JOIN film_category fc ON f.film_id = fc.film_id
            LEFT JOIN category c ON fc.category_id = c.category_id
            LEFT JOIN film_actor fa ON f.film_id = fa.film_id
            LEFT JOIN actor a ON fa.actor_id = a.actor_id
            WHERE 1=1
        """;

        if (titulo != null && !titulo.isEmpty()) {
            sql += " AND LOWER(f.title) LIKE LOWER(:titulo)";
        }
        if (categoria != null && !categoria.isEmpty()) {
            sql += " AND LOWER(c.name) LIKE LOWER(:categoria)";
        }
        if (actor != null && !actor.isEmpty()) {
            sql += " AND LOWER(a.first_name || ' ' || a.last_name) LIKE LOWER(:actor)";
        }
        if (rating != null && !rating.isEmpty()) {
            sql += " AND f.rating::text = :rating";
        }

        sql += """
            GROUP BY 
                f.film_id, 
                f.title, 
                f.release_year, 
                f.rating, 
                c.name
        """;

        var query = em.createNativeQuery(sql);

        if (titulo != null && !titulo.isEmpty()) {
            query.setParameter("titulo", "%" + titulo + "%");
        }
        if (categoria != null && !categoria.isEmpty()) {
            query.setParameter("categoria", "%" + categoria + "%");
        }
        if (actor != null && !actor.isEmpty()) {
            query.setParameter("actor", "%" + actor + "%");
        }
        if (rating != null && !rating.isEmpty()) {
            query.setParameter("rating", rating);
        }

        return query.getResultList();
    }
}
