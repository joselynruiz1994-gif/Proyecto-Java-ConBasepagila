package com.web_cliente.service;

import java.util.List;

public interface ReporteService {
	
	List<Object[]> ingresosMensuales();

    List<Object[]> topPeliculas();

    List<Object[]> topClientes();


}
