package com.web_cliente.service;

import java.util.List;
import java.util.Optional;

import com.web_cliente.modelo.Actor;

public interface ActorService {

    List<Actor> listarTodos();
}