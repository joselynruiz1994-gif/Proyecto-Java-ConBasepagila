package com.web_cliente.service;

import java.util.List;

import com.web_cliente.modelo.Payment;
import com.web_cliente.modelo.Rental;

public interface ClienteService {
	

    List<Object[]> listarClientes();

    Object buscarCliente(Integer id);

    List<Object[]> historialAlquileres(Integer id);

    List<Object[]> historialPagos(Integer id);
}


