package com.web_cliente.service;
import java.util.List;
import java.time.LocalDate;

public interface AlquilerService {
	List<Object[]> listarAlquileres();

    List<Object[]> listarAlquileresPorFechaYTienda(
    		String inicio, String fin, Integer tienda);
}