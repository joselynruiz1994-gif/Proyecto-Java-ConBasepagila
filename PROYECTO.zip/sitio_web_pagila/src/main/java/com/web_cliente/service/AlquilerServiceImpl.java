package com.web_cliente.service;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web_cliente.repository.AlquilerRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web_cliente.repository.AlquilerRepository;

@Service
public class AlquilerServiceImpl implements AlquilerService {

    @Autowired
    private AlquilerRepository repo;

    @Override
    public List<Object[]> listarAlquileres() {
        return repo.listarAlquileres();
    }

    @Override
    public List<Object[]> listarAlquileresPorFechaYTienda(String inicioStr, String finStr, Integer tienda) {
        LocalDateTime inicio = null;
        LocalDateTime fin = null;

        try {
            if (inicioStr != null && !inicioStr.isEmpty()) {
                inicio = LocalDate.parse(inicioStr).atStartOfDay(); // 00:00:00
            }
            if (finStr != null && !finStr.isEmpty()) {
                fin = LocalDate.parse(finStr).atTime(LocalTime.MAX); // 23:59:59.999999999
            }
        } catch (Exception e) {
            // Si hay error de parseo, deja null para no filtrar
            inicio = null;
            fin = null;
        }

        return repo.listarAlquileresPorFechaYTienda(inicio, fin, tienda);
    }
}