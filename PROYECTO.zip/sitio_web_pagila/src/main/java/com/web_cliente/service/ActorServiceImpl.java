package com.web_cliente.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.web_cliente.modelo.Actor;
import com.web_cliente.repository.ActorRepository;

@Service
public class ActorServiceImpl implements ActorService {

	private final ActorRepository actorRepository;

    public ActorServiceImpl(ActorRepository actorRepository) {
        this.actorRepository = actorRepository;
    }

    @Override
    public List<Actor> listarTodos() {
        return actorRepository.findAll();
    }
}