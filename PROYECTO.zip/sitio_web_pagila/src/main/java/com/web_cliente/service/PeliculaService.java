package com.web_cliente.service;

import java.util.List;

public interface PeliculaService {
	List<Object[]> buscarPeliculas(
	        String titulo,
	        String categoria,
	        String actor,
	        String rating
	    );

}
