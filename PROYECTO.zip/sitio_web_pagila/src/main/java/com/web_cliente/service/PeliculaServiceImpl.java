package com.web_cliente.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web_cliente.repository.PeliculaRepository;

@Service
public class PeliculaServiceImpl implements PeliculaService {

    @Autowired
    private PeliculaRepository repo;

    @Override
    public List<Object[]> buscarPeliculas(
            String titulo,
            String categoria,
            String actor,
            String rating
    ) {
        return repo.buscarPeliculas(titulo, categoria, actor, rating);
    }

}
