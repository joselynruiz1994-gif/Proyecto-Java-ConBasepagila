package com.web_cliente.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.web_cliente.repository.DashboardRepository;


@Service
public class DashboardService {
	
	@Autowired
    private DashboardRepository repo;

    public Long alquileres() {
        return repo.totalAlquileres();
    }

    public Double ingresos() {
        return repo.totalIngresos();
    }

    public Long clientesActivos() {
        return repo.clientesActivos();
    }


}
