package com.web_cliente.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web_cliente.modelo.Film;
import com.web_cliente.repository.FilmRepository;
@Service
public class FilmServiceImpl implements FilmService {

    @Autowired
    private FilmRepository filmRepository;

    @Override
    public List<Film> listarTodos() {
        return filmRepository.findAll();
    }

    @Override
    public List<Film> listarTodosConActores() {
        return filmRepository.findAllWithActors();
    }

    @Override
    public List<Film> buscarPorTitulo(String titulo) {
        return filmRepository.findByTitleContainingIgnoreCase(titulo);
    }

    @Override
    public List<Film> buscarPorActor(String actor) {
        return filmRepository.findByActor(actor);
    }
}