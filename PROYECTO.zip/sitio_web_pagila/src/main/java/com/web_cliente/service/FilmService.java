package com.web_cliente.service;
import java.util.List;
import com.web_cliente.modelo.Film;

public interface FilmService {
	
	List<Film> listarTodos();
	
    List<Film> listarTodosConActores();

    List<Film> buscarPorTitulo(String titulo);

    List<Film> buscarPorActor(String actor);
}