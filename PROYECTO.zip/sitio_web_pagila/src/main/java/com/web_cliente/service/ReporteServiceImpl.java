package com.web_cliente.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web_cliente.repository.ReporteRepository;

@Service
public class ReporteServiceImpl implements ReporteService{
	
	@Autowired
    private ReporteRepository repo;

    @Override
    public List<Object[]> ingresosMensuales() {
        return repo.ingresosMensuales();
    }

    @Override
    public List<Object[]> topPeliculas() {
        return repo.topPeliculas();
    }

    @Override
    public List<Object[]> topClientes() {
        return repo.topClientes();
    }


}
