package com.web_cliente.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web_cliente.repository.ClienteRepository;

@Service
public class ClienteServiceImpl implements ClienteService{
	@Autowired
    private ClienteRepository repo;

    @Override
    public List<Object[]> listarClientes() {
        return repo.listarClientes();
    }

    @Override
    public Object buscarCliente(Integer id) {
        return repo.buscarCliente(id);
    }

    @Override
    public List<Object[]> historialAlquileres(Integer id) {
        return repo.historialAlquileres(id);
    }

    @Override
    public List<Object[]> historialPagos(Integer id) {
        return repo.historialPagos(id);
    }
}

