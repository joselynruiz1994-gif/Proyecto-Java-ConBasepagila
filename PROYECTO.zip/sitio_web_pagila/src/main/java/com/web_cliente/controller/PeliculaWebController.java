package com.web_cliente.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.web_cliente.service.PeliculaService;

@Controller
public class PeliculaWebController {
	@Autowired
    private PeliculaService service;

    @GetMapping("/peliculas")
    public String peliculas(
        @RequestParam(required = false) String titulo,
        @RequestParam(required = false) String categoria,
        @RequestParam(required = false) String actor,
        @RequestParam(required = false) String rating,
        Model model
    ) {

        List<Object[]> peliculas =
            service.buscarPeliculas(titulo, categoria, actor, rating);

        model.addAttribute("peliculas", peliculas);

        return "peliculas";
    }
}
