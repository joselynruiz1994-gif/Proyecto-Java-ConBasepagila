package com.web_cliente.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.web_cliente.service.ClienteService;

@Controller
@RequestMapping("/clientes")
public class ClienteController {

    @Autowired
    private ClienteService service;

    // 👉 MENÚ / LISTADO DE CLIENTES
    @GetMapping
    public String listarClientes(Model model) {
        model.addAttribute("clientes", service.listarClientes());
        return "clientes/index";
    }


    // 👉 HISTORIAL DE UN CLIENTE
    @GetMapping("/{id}")
    public String historialCliente(@PathVariable Integer id, Model model) {
        model.addAttribute("cliente", service.buscarCliente(id));
        model.addAttribute("alquileres", service.historialAlquileres(id));
        model.addAttribute("pagos", service.historialPagos(id));
        return "clientes/historial";
    }

}


