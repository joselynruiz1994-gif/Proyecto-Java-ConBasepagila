package com.web_cliente.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.web_cliente.service.AlquilerService;

@Controller
@RequestMapping("/alquileres")
public class AlquilerController {
	 @Autowired
	    private AlquilerService service;

	    // Vista principal: lista los últimos 50 alquileres
	    @GetMapping
	    public String listarAlquileres(Model model) {
	        model.addAttribute("alquileres", service.listarAlquileres());
	        return "alquileres/index";
	    }

	    // Filtrar alquileres por fechas y tienda
	    @GetMapping("/filtrar")
	    public String filtrarAlquileres(
	            @RequestParam String inicio,
	            @RequestParam String fin,
	            @RequestParam Integer tienda,
	            Model model) {

	        model.addAttribute("alquileres",
	                service.listarAlquileresPorFechaYTienda(inicio, fin, tienda));

	        return "alquileres/index";
	    }
	}



