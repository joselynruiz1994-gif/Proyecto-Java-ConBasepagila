package com.web_cliente.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.web_cliente.modelo.Film;

import com.web_cliente.service.FilmService;

@Controller
public class FilmController {
	
	@Autowired
    private FilmService filmService; 

	@GetMapping("/films")
    public String listarPeliculas(
            @RequestParam(required = false) String titulo,
            @RequestParam(required = false) String actor,
            Model model) {

        List<Film> films;

        if (actor != null && !actor.isEmpty()) {
            films = filmService.buscarPorActor(actor);
        } else if (titulo != null && !titulo.isEmpty()) {
            films = filmService.buscarPorTitulo(titulo);
        } else {
            films = filmService.listarTodosConActores();
        }

        model.addAttribute("films", films);
        return "films/lista";
    }
}