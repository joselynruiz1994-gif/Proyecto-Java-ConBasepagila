	package com.web_cliente.controller;
	
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestParam;
	
	import com.web_cliente.service.ActorService;
	
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	
	
	@Controller
	@RequestMapping("/actores")
	public class ActorController {
		
		private final ActorService actorService;
	
	    public ActorController(ActorService actorService) {
	        this.actorService = actorService;
	    }
	
	    @GetMapping
	    public String listar(Model model) {
	        model.addAttribute("actores", actorService.listarTodos());
	        return "actores/list";
	    }
	
	}
