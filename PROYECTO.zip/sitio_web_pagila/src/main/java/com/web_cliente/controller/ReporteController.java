package com.web_cliente.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.web_cliente.service.ReporteService;

@Controller
@RequestMapping("/reportes")
public class ReporteController {
	
	@Autowired
    private ReporteService service;

    // 👉 MENÚ DE REPORTES
    @GetMapping
    public String menuReportes() {
        return "reportes/index";
    }

    // 👉 TOP PELÍCULAS
    @GetMapping("/top-peliculas")
    public String topPeliculas(Model model) {
        model.addAttribute("lista", service.topPeliculas());
        return "reportes/top-peliculas";
    }

    // 👉 TOP CLIENTES
    @GetMapping("/top-clientes")
    public String topClientes(Model model) {
        model.addAttribute("lista", service.topClientes());
        return "reportes/top-clientes";
    }

    // 👉 INGRESOS MENSUALES
    @GetMapping("/ingresos-mensuales")
    public String ingresosMensuales(Model model) {
        model.addAttribute("lista", service.ingresosMensuales());
        return "reportes/ingresos-mensuales";
        
    
    }
}